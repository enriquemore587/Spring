package more.spring.jdbc.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import more.spring.jdbc.dao.ClientDAO;
import more.spring.jdbc.mappers.ClientMapper;
import more.spring.jdbc.models.Client;

public class ClientDAOImpl implements ClientDAO {
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void setDataSource(DataSource ds) {
		// TODO Auto-generated method stub
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void insert(String name, String country, String phone, Integer age) {
		// TODO Auto-generated method stub
		String SQL = "insert into cliente (name, country, phone, age) values (?, ?, ?, ?)";
		
		jdbcTemplate.update(SQL, name, country, phone, age);
		System.out.println("Se creo el nuevo REGISTRO");
	}

	@Override
	public Client selectById(Integer id) {
		// TODO Auto-generated method stub
		
		String SQL = "select * from cliente where id = ?";
		Client client = jdbcTemplate.queryForObject(SQL, new Object[] {id}, new ClientMapper());
		return client;
	}

	@Override
	public List<Client> selectAll() {
		// TODO Auto-generated method stub
		String SQL = "SELECT * FROM cliente";
		List<Client> listClient = jdbcTemplate.query(SQL, new ClientMapper());
		return listClient;
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		String SQL = "delete from cliente where id = ?";
		jdbcTemplate.update(SQL, id);
		System.out.println("Elemento con el ID " + id + " ELIMINADO");
	}

	@Override
	public void update(Integer id, String name) {
		// TODO Auto-generated method stub
		String SQL = "update cliente set name = ? where id = ?";
		jdbcTemplate.update(SQL, name, id);
		System.out.println("Se actulizo el registro con el ID: "+id+" con el nuevo nombre: "+name);
	}

}
