package more.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import more.spring.jdbc.dao.ClientDAO;
import more.spring.jdbc.models.Client;

public class Inicio {
	
	public static void main(String[] args) {
		ApplicationContext contnext = 
				new ClassPathXmlApplicationContext("beans.xml");
		ClientDAO clientDAO = (ClientDAO) contnext.getBean("clientJdbcTemplate");
		System.out.println("CREANDO CLIENTES - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
		clientDAO.insert("JOSE", "MÉXICO", "55123456", 23);
		clientDAO.insert("MARIANA", "ARGENTINA", "55185641", 28);
		clientDAO.insert("LUCY", "CANADA", "559632178", 21);
		clientDAO.insert("ENRIQUE", "MÉXICO", "000000", 15);		
		
		selectAllClientes(clientDAO);
		
		clientDAO.update(3, "GOKU");
		System.out.println("CREANDO CLIENTE CON ID 3- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
		Client client = clientDAO.selectById(3);
		System.out.println(client.getName());
		System.out.println(client.getCountry());
	}
	private static void selectAllClientes(ClientDAO clientDAO){
		System.out.println("LISTANDO TODOS LOS CLIENTES - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
		List<Client> listaCliente = clientDAO.selectAll();
		for (Client client : listaCliente) {
			System.out.println("ID: "+client.getId());
			System.out.println("NOMBRE: "+client.getName());
			System.out.println("TELENONO: "+client.getPhone());
			System.out.println("CIUDAD: "+client.getCountry());
			System.out.println("EDAD: "+client.getAge());			
		}
		System.out.println();
	}
}
