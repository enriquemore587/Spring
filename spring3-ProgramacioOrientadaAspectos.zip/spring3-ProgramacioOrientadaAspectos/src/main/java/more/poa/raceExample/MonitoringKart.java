package more.poa.raceExample;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MonitoringKart {

	
	@Before("execution(* more.poa.raceExample.Kart.move(..))")
	public void movingKart(){
		System.out.println("Kart movig");
	}
	
	@Before("execution(* more.poa.raceExample.Kart.move(..))")
	public void movingKart(JoinPoint joinPoint){
		String methodName = joinPoint.getSignature().toShortString();
		System.out.println(methodName + " Kart Moving with JOIN POINT");
	}
	
	@AfterReturning(value="execution(* more.poa.raceExample.Kart.move(..))",
			returning="distance")
	public void movingKart(JoinPoint joinPoint, int distance){
		System.out.println(joinPoint.getThis().toString()
				+" Kart moved: "+ distance);
	}
	
	@AfterReturning(value="execution(* more.poa.raceExample.Kart.move(..))", returning="handlePoints")
	public void handlerKart(JoinPoint joinPoint, int handlePoints){
		Kart callingKart = (Kart) joinPoint.getThis();
		System.out.println(callingKart.getName()
				+"  handle: "+ handlePoints);
	}
	
}
