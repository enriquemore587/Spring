package com.example.demo;

public interface Vehicle {
	public void move();
}
