package com.example.demo;

public class Car implements Vehicle {
	private int petrolTank;
	@Override
	public void move() {
		// TODO Auto-generated method stub
		if (petrolTank > 0) {
			petrolTank--;
		}
	}

}
