package com.example.demo;

public class Driver1 {
	Car1 car1 = new Car1();
	
	public void drive() {
		// TODO Auto-generated method stub
		car1.move();
	}
}