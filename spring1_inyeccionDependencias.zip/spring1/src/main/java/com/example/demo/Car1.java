package com.example.demo;

public class Car1 {
	public void move() {
		// TODO Auto-generated method stub

	}
}
