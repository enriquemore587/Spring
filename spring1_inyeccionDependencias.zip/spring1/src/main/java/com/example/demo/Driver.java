package com.example.demo;

public class Driver {
	private Vehicle vehicle;
	public Driver(Vehicle vehicle) {
		// TODO Auto-generated constructor stub
		this.vehicle = vehicle;
	}
	
	public void drive() {
		// TODO Auto-generated method stub
		vehicle.move();
	}
}
