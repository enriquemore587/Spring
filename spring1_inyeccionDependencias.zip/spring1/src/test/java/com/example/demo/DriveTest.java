package com.example.demo;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Test;

public class DriveTest {
	
	@Test
	public void driveCallMove() {
		// TODO Auto-generated method stub
		Vehicle falseVehicle = mock(Vehicle.class);
		
		Driver driver = new Driver(falseVehicle);
			driver.drive();
		
			verify(falseVehicle, times(1)).move();
	}
}
