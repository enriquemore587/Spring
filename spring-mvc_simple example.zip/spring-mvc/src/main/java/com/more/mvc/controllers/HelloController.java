package com.more.mvc.controllers;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
	public HelloController() {
		// TODO Auto-generated constructor stub
		System.out.println("BEAN instantiated");
	}
	
	
	@RequestMapping(method =  RequestMethod.GET, value = "/hello")
	public String sayHelloPage(Map<String, Object> model){
		System.out.println("inside sayHelloPage");
		model.put("greet", "Hello World, welcome to my app\n by. Enrique");
		return "hello";
	}
}
